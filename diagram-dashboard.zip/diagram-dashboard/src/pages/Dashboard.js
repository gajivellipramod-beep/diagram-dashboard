import React, { useState } from "react";
import UploadBox from "../components/UploadBox";
import DiagramViewer from "../components/DiagramViewer";
import ComponentList from "../components/ComponentList";

function Dashboard() {
  const [uploadedImage, setUploadedImage] = useState(null);
  const [components] = useState([
    { id: 1, name: "Resistor" },
    { id: 2, name: "Capacitor" },
    { id: 3, name: "Diode" },
    { id: 4, name: "Transistor" }
  ]);

  return (
    <div style={{ width: "100vw", height: "100vh", position: "relative", overflow: "hidden", display: "flex", flexDirection: "column" }}>
      
      <div style={{ height: "80px", borderBottom: "1px solid #ddd", padding: "0 20px", display: "flex", alignItems: "center", flexShrink: 0, backgroundColor: "white" }}>
        <UploadBox onImageUpload={setUploadedImage} />
      </div>

      <div style={{ display: "flex", flexGrow: 1, position: "relative" }}>
        
        <div style={{ width: "calc(100% - 300px)", height: "100%", position: "relative", overflow: "hidden" }}>
          <DiagramViewer image={uploadedImage} />
        </div>

        <div style={{ width: "300px", height: "100%", borderLeft: "1px solid #ddd", backgroundColor: "white", overflowY: "auto", flexShrink: 0 }}>
          <ComponentList components={components} />
        </div>

      </div>
    </div>
  );
}

export default Dashboard;