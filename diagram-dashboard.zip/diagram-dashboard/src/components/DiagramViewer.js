import React,{useState} from "react";

function DiagramViewer({image}){

  const [zoom,setZoom] = useState(1);

  function zoomIn(){
    setZoom(zoom + 0.1);
  }

  function zoomOut(){
    setZoom(zoom - 0.1);
  }

  function resetZoom(){
    setZoom(1);
  }

  return(

    <div>

      <div style={{marginBottom:"10px"}}>
        <button onClick={zoomIn}>Zoom In</button>
        <button onClick={zoomOut}>Zoom Out</button>
        <button onClick={resetZoom}>Reset</button>
      </div>

      <div
        style={{
          width:"100%",
          height:"450px",
          border:"2px solid #ccc",
          overflow:"auto",
          display:"flex",
          justifyContent:"center",
          alignItems:"center"
        }}
      >

        {image && (
          <img
            src={image}
            alt="diagram"
            style={{
              maxWidth:"100%",
              maxHeight:"100%",
              transform:`scale(${zoom})`,
              transformOrigin:"center"
            }}
          />
        )}

      </div>

    </div>

  )
}

export default DiagramViewer;