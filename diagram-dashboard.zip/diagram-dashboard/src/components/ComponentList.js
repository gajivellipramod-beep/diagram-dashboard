import React from "react";

function ComponentList({ components }) {
  const itemStyle = {
    padding: "12px 15px",
    borderBottom: "1px solid #eee",
    fontSize: "15px",
    color: "#333",
    backgroundColor: "#fcfcfc",
    marginBottom: "5px",
    borderRadius: "4px",
    boxShadow: "0 1px 2px rgba(0,0,0,0.05)"
  };

  return (
    <div>
      <h3 style={{ marginTop: 0, marginBottom: "15px", color: "#333", fontSize: "18px", borderBottom: "2px solid #007bff", paddingBottom: "8px", display: "inline-block" }}>
        Detected Components
      </h3>
      
      <div style={{ display: "flex", flexDirection: "column" }}>
        {components.length > 0 ? (
          components.map((comp) => (
            <div key={comp.id} style={itemStyle}>
              {comp.name}
            </div>
          ))
        ) : (
          <p style={{ color: "#999", fontSize: "14px" }}>No components detected.</p>
        )}
      </div>
    </div>
  );
}

export default ComponentList;