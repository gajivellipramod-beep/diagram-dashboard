import React from "react";

function UploadBox({ onImageUpload }) {
  const handleFileChange = (event) => {
    const file = event.target.files[0];
    if (file) {
      const imageUrl = URL.createObjectURL(file);
      onImageUpload(imageUrl);
    }
  };

  return (
    <div style={{ display: "flex", alignItems: "center", gap: "15px" }}>
      <h3 style={{ margin: 0, fontSize: "16px", color: "#555" }}>Upload Diagram:</h3>
      <input 
        type="file" 
        accept="image/png, image/jpeg" 
        onChange={handleFileChange}
        style={{
          padding: "8px",
          border: "1px solid #ccc",
          borderRadius: "4px",
          cursor: "pointer"
        }}
      />
    </div>
  );
}

export default UploadBox;